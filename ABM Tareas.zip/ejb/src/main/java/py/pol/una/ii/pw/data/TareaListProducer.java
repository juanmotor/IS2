package py.pol.una.ii.pw.data;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.event.Reception;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import py.pol.una.ii.pw.model.Tarea;
import py.pol.una.ii.pw.model.views.TareaView;

@RequestScoped
public class TareaListProducer {
	@Inject
    private TareaRepository tareaRepository;
	
	private List<TareaView> tareas;
	
	@Produces
    @Named
    public List<TareaView> getTareas() {
        return tareas;
    }

    public void onTareaListChanged(@Observes(notifyObserver = Reception.IF_EXISTS) final Tarea tarea) {
        retrieveAllTareaOrderedByName();
    }

    @PostConstruct
    public void retrieveAllTareaOrderedByName() {
    	tareas = tareaRepository.findAllOrderedById();
    }
}
