package py.pol.una.ii.pw.data;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import py.pol.una.ii.pw.model.Tarea;
import py.pol.una.ii.pw.model.views.TareaView;

@ApplicationScoped
public class TareaRepository {

	@Inject
    private EntityManager em;

    public Tarea findTareaById(Long id) {
        return em.find(Tarea.class, id);
    }

    public List<TareaView> findAllOrderedById() {
        TypedQuery<Tarea> tq = em.createQuery("Select r from Tarea r", Tarea.class);
       
        List<TareaView> tareas = new ArrayList<TareaView>();
        
        	
        for(Tarea t : tq.getResultList()){
        	tareas.add(new TareaView(t));
        }
        
        return tareas;
    }
}
