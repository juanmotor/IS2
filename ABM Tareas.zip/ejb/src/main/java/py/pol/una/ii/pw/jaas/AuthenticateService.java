package py.pol.una.ii.pw.jaas;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;

import py.pol.una.ii.pw.model.Usuario;
import py.pol.una.ii.pw.model.views.Authenticate;

public class AuthenticateService {
	@Inject
    private EntityManager em;

    public Authenticate authenticate(String user, String password) throws Exception{
        Authenticate r = new Authenticate();
        TypedQuery<Usuario> tq = em.
                createQuery("Select u from Usuario u where u.username=:user and u.password=:pass",
                        Usuario.class);
        tq.setParameter("user", user);
        tq.setParameter("pass", toSHA(password));
        try{
        	Usuario usuario = (Usuario) tq.getSingleResult();
        	r.setEstado(true);
            r.setRol(usuario.getRoles().getDescripcion());
            r.setUsername(usuario.getNombre()+" "+ usuario.getApellido());
            return r;
        } catch(NoResultException e){
        	throw new Exception("Crendenciales invalidas");
        } catch(NonUniqueResultException e){
        	throw new Exception("Crendenciales invalidas");
        }
    }

    public String toSHA(String password){
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        md.update(password.getBytes());
        byte byteData[] = md.digest();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }

        return  sb.toString();
    }
}
