package py.pol.una.ii.pw.model.views;

public class Authenticate {
	
	private Boolean estado;
	private String rol;
	private String username;
	
	public Authenticate() {
	}
	public Boolean getEstado() {
		return estado;
	}
	public void setEstado(Boolean estado) {
		this.estado = estado;
	}
	public String getRol() {
		return rol;
	}
	public void setRol(String rol) {
		this.rol = rol;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
	 
}
