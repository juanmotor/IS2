package py.pol.una.ii.pw.model.views;

import java.util.Date;

import py.pol.una.ii.pw.model.Tarea;
import py.pol.una.ii.pw.model.Usuario;

public class TareaView {
	
	private Long idTarea;
	private String titulo;
	private String descripcion;
	private UsuarioView asignado;
	private Date fechaInicio;
	private Date fechaFin;
	private String estado;
	private String prioridad;
	
	public TareaView(Long idTarea, String titulo, String descripcion,
			UsuarioView asignado, Date fechaInicio, Date fechaFin,
			String estado, String prioridad) {
		this.idTarea = idTarea;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.asignado = asignado;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.estado = estado;
		this.prioridad = prioridad;
	}
	
	public TareaView() {
	}
	public TareaView(Tarea t) {
		this.idTarea = t.getIdTarea();
		this.titulo = t.getTitulo();
		this.descripcion = t.getDescripcion();
		this.fechaFin = t.getFechaFin();
		this.fechaInicio = t.getFechaInicio();
		this.estado = t.getEstado();
		this.prioridad = t.getPrioridad();
		bindUsuario(t.getAsignado());	
	}
	
	public Long getIdTarea() {
		return idTarea;
	}
	public void setIdTarea(Long idTarea) {
		this.idTarea = idTarea;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public UsuarioView getAsignado() {
		return asignado;
	}
	public void setAsignado(UsuarioView asignado) {
		this.asignado = asignado;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getPrioridad() {
		return prioridad;
	}
	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}	
	
	private void bindUsuario(Usuario u){
		UsuarioView v = new UsuarioView();
		v.setIdUsuario(u.getIdUsuario());
		v.setApellido(u.getApellido());
		v.setEmail(u.getEmail());
		v.setNombre(u.getNombre());
		v.setUsername(u.getUsername());
		v.setRol(u.getRoles().getDescripcion());
		
		this.asignado = v;
	}
}
