package py.pol.una.ii.pw.filter;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import py.pol.una.ii.pw.jaas.AuthenticateService;
import py.pol.una.ii.pw.model.views.Authenticate;

import com.google.gson.Gson;

public class AuthenticateFilter implements Filter {
	@Inject
    private AuthenticateService authenticateService;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
			
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String user = request.getParameter("user");
        String pass = request.getParameter("password");

        try{
            Authenticate auth = authenticateService.authenticate(user, pass);
            Gson gson = new Gson();
            String authjson = gson.toJson(auth);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(authjson);
        
        }catch(Exception e){
        	Authenticate auth = new Authenticate();
        	auth.setEstado(false);
        	auth.setRol("");
        	auth.setUsername("");
        	Gson gson = new Gson();
            String json = gson.toJson(auth);
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json);
        }
	}

	@Override
	public void destroy() {
	}

}
