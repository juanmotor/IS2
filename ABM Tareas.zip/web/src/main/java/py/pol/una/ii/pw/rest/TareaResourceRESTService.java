package py.pol.una.ii.pw.rest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.validation.Validator;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import py.pol.una.ii.pw.data.TareaRepository;
import py.pol.una.ii.pw.model.Tarea;
import py.pol.una.ii.pw.model.views.TareaView;
import py.pol.una.ii.pw.service.TereaRegistration;

@Path("/tareas")
@RequestScoped
public class TareaResourceRESTService {
	@Inject
    private Logger log;

    @Inject
    private Validator validator;
    
    @Inject
    private TareaRepository repository;
    
    @Inject
    private TereaRegistration registration;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<TareaView> listAllTarea() {
        return repository.findAllOrderedById();
    }
    
    @GET
    @Path("/{id:[0-9][0-9]*}")
    @Produces(MediaType.APPLICATION_JSON)
    public Tarea lookupRolById(@PathParam("id") long id) {
    	Tarea tarea = repository.findTareaById(id);
        if (tarea == null) {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
        return tarea;
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMember(Tarea tarea) {
        Response.ResponseBuilder builder = null;
        try {
            registration.register(tarea);
            builder = Response.ok();
        } catch (Exception e) {
            Map<String, String> responseObj = new HashMap<String, String>();
            responseObj.put("error", e.getMessage());
            builder = Response.status(Response.Status.BAD_REQUEST).entity(responseObj);
        }
        return builder.build();
    }
    
}
