--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

-- Started on 2018-03-11 23:11:02

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12387)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2173 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 187 (class 1259 OID 16419)
-- Name: permiso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permiso (
    permiso_id numeric NOT NULL,
    nombre character varying NOT NULL,
    fecha_creacion date NOT NULL,
    nivel_de_permiso character varying NOT NULL
);


ALTER TABLE public.permiso OWNER TO postgres;

--
-- TOC entry 188 (class 1259 OID 16427)
-- Name: proyecto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proyecto (
    proyecto_id numeric NOT NULL,
    nombre character varying NOT NULL,
    fecha_inicio date NOT NULL,
    descripcion character varying NOT NULL,
    duracion_sprint integer NOT NULL
);


ALTER TABLE public.proyecto OWNER TO postgres;

--
-- TOC entry 186 (class 1259 OID 16402)
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol (
    rol_id numeric NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.rol OWNER TO postgres;

--
-- TOC entry 189 (class 1259 OID 16435)
-- Name: sprint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sprint (
    sprint_id numeric NOT NULL,
    descripcion character varying,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    fecha_creacion date NOT NULL
);


ALTER TABLE public.sprint OWNER TO postgres;

--
-- TOC entry 190 (class 1259 OID 16443)
-- Name: userhistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userhistory (
    id numeric NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying NOT NULL,
    fecha_creacion date NOT NULL,
    fecha_eliminacion date NOT NULL,
    fecha_modificacion date NOT NULL
);


ALTER TABLE public.userhistory OWNER TO postgres;

--
-- TOC entry 185 (class 1259 OID 16394)
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usuario_id numeric(4,0) NOT NULL,
    nombre character varying NOT NULL,
    apellido character varying NOT NULL,
    telefono character varying NOT NULL,
    direccion character varying NOT NULL,
    correo character varying,
    sexo character varying NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- TOC entry 2162 (class 0 OID 16419)
-- Dependencies: 187
-- Data for Name: permiso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permiso (permiso_id, nombre, fecha_creacion, nivel_de_permiso) FROM stdin;
1	Administrador	2018-03-11	3
\.


--
-- TOC entry 2163 (class 0 OID 16427)
-- Dependencies: 188
-- Data for Name: proyecto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proyecto (proyecto_id, nombre, fecha_inicio, descripcion, duracion_sprint) FROM stdin;
\.


--
-- TOC entry 2161 (class 0 OID 16402)
-- Dependencies: 186
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rol (rol_id, nombre) FROM stdin;
1	administrador
\.


--
-- TOC entry 2164 (class 0 OID 16435)
-- Dependencies: 189
-- Data for Name: sprint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sprint (sprint_id, descripcion, fecha_inicio, fecha_fin, fecha_creacion) FROM stdin;
\.


--
-- TOC entry 2165 (class 0 OID 16443)
-- Dependencies: 190
-- Data for Name: userhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.userhistory (id, descripcion, estado, fecha_creacion, fecha_eliminacion, fecha_modificacion) FROM stdin;
\.


--
-- TOC entry 2160 (class 0 OID 16394)
-- Dependencies: 185
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (usuario_id, nombre, apellido, telefono, direccion, correo, sexo) FROM stdin;
1	juan	nunez	021640019	rosa a gonzalez 2097	juama92@hotmail.com	masculino
\.


--
-- TOC entry 2031 (class 2606 OID 16426)
-- Name: permiso permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_pkey PRIMARY KEY (permiso_id);


--
-- TOC entry 2033 (class 2606 OID 16434)
-- Name: proyecto proyecto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto
    ADD CONSTRAINT proyecto_pkey PRIMARY KEY (proyecto_id);


--
-- TOC entry 2029 (class 2606 OID 16409)
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (rol_id);


--
-- TOC entry 2035 (class 2606 OID 16442)
-- Name: sprint sprint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint
    ADD CONSTRAINT sprint_pkey PRIMARY KEY (sprint_id);


--
-- TOC entry 2037 (class 2606 OID 16450)
-- Name: userhistory userhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userhistory
    ADD CONSTRAINT userhistory_pkey PRIMARY KEY (id);


--
-- TOC entry 2027 (class 2606 OID 16411)
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usuario_id);


--
-- TOC entry 2039 (class 2606 OID 16451)
-- Name: rol fk_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT fk_rol FOREIGN KEY (rol_id) REFERENCES public.permiso(permiso_id);


--
-- TOC entry 2040 (class 2606 OID 16466)
-- Name: sprint fk_sprint_proyecto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sprint
    ADD CONSTRAINT fk_sprint_proyecto FOREIGN KEY (sprint_id) REFERENCES public.proyecto(proyecto_id);


--
-- TOC entry 2042 (class 2606 OID 16471)
-- Name: userhistory fk_uh_sprint; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userhistory
    ADD CONSTRAINT fk_uh_sprint FOREIGN KEY (id) REFERENCES public.sprint(sprint_id);


--
-- TOC entry 2041 (class 2606 OID 16461)
-- Name: userhistory fk_uh_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userhistory
    ADD CONSTRAINT fk_uh_usuario FOREIGN KEY (id) REFERENCES public.usuario(usuario_id);


--
-- TOC entry 2038 (class 2606 OID 16456)
-- Name: usuario fk_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT fk_usuario FOREIGN KEY (usuario_id) REFERENCES public.rol(rol_id);


--
-- TOC entry 1677 (class 826 OID 16477)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO PUBLIC;


-- Completed on 2018-03-11 23:11:05

--
-- PostgreSQL database dump complete
--

