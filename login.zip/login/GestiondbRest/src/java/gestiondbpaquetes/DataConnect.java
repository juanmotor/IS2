/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondbpaquetes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
public class DataConnect {
 public static Connection getConnection() {
 try {
 Class.forName("org.postgresql.Driver");
 Connection con = DriverManager.getConnection(
 "jdbc:postgresql://localhost:5432/gestionbd",
"postgres",
"is2");
 return con;
 } catch (ClassNotFoundException | SQLException ex) {
 System.out.println("Database.getConnection() Error -->"
 + ex.getMessage());
 return null;
 }
 }
 public static void close(Connection con) {
 try {
 con.close();
 } catch (Exception ex) {
ex.printStackTrace();
 }
 }
 

private boolean validate(String username, String password) {
 Connection con = null;
 PreparedStatement ps = null;
 try {
 con = DataConnect.getConnection();
 ps = con.prepareStatement("Select nombre, "
 + "contraseña "
+ "from usuario "
+ "where nombre = ? and contraseña = ?");
 ps.setString(1, username);
 ps.setString(2, password);
 ResultSet rs = ps.executeQuery();
 if (rs.next()) {
 return true;
 }
 } catch (SQLException ex) {
 System.out.println("Login error -->" + ex.getMessage());
 return false;
 } finally {
 DataConnect.close(con);
 }
 return false;
 }
 public String validateUsernamePassword() {
 boolean valid = validate(username, password);
 if (valid) {
 HttpSession session = SessionBean.getSession();
 session.setAttribute("username", username);
 logueado = true;
 return "home";
 } else {
 FacesContext.getCurrentInstance().addMessage(null,
 new FacesMessage(FacesMessage.SEVERITY_WARN,
 "Usuario y Contraseña invalida",
 "Por favor ingrese Usuario y Contraseña"));
 return "Login";
 }

}
